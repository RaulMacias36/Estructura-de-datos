import subprocess
import sys
import os
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import time
import json
import random
import csv
from datetime import datetime

# --- BLOQUE DE AUTO-INSTALACIÓN ---
def install_dependencies():
    try:
        import openpyxl
    except ImportError:
        print("Instalando librería para Excel (openpyxl)...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "openpyxl"])

install_dependencies()
from openpyxl import Workbook, load_workbook
from openpyxl.utils import get_column_letter

# --- IMPORTACIÓN DE TUS LIBRERÍAS ---
try:
    from internal_sort import InternalSort
    from external_sort import ExternalSort
    print("Librerías cargadas con éxito")
except ImportError as e:
    print(f"Error de importación detallado: {e}")
    messagebox.showerror("Error Crítico", 
        f"No se pudieron cargar las librerías.\nError: {e}\n\n"
        "Asegúrate de que los archivos internal_sort.py y external_sort.py estén en la misma carpeta.")

class SortingApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Sistema Integral de Ordenamiento Animado v3.0")
        self.root.geometry("1100x1000")
        self.root.configure(bg="#0f172a")

        self.all_data = []
        self.sorting_active = False  
        self.canvas_width = 1000
        self.canvas_height = 250
        self.current_excel_path = ""
        self.output_dir = "archivos_generados"
        if not os.path.exists(self.output_dir): os.makedirs(self.output_dir)
            
        self.setup_ui()

    def setup_ui(self):
        header = tk.Label(self.root, text="LABORATORIO DE ORDENAMIENTO", 
                         bg="#0f172a", fg="#10b981", font=("Segoe UI", 24, "bold"))
        header.pack(pady=15)

        # --- PANEL: ENTRADA MANUAL Y CARGA ---
        input_frame = tk.LabelFrame(self.root, text=" 📥 Entrada de Datos ", 
                                   bg="#1e293b", fg="#f8fafc", font=("Segoe UI", 10, "bold"), padx=15, pady=10)
        input_frame.pack(fill="x", padx=25, pady=5)

        tk.Label(input_frame, text="Manual:", bg="#1e293b", fg="white").pack(side="left")
        self.manual_entry = ttk.Entry(input_frame, width=45)
        self.manual_entry.pack(side="left", padx=10)
        
        tk.Button(input_frame, text="➕ Añadir", command=self.add_manual_data,
                  bg="#10b981", fg="white", relief="flat", width=10).pack(side="left", padx=5)
        
        tk.Button(input_frame, text="📁 Cargar Archivos", command=self.load_multiple_files,
                  bg="#38bdf8", fg="#0f172a", font=("Segoe UI", 9, "bold")).pack(side="right")
        
        tk.Button(input_frame, text="🗑️ Limpiar", command=self.clear_data,
                  bg="#ef4444", fg="white", width=10).pack(side="right", padx=10)

        # --- PANEL DINÁMICO: CONFIGURACIÓN EXCEL ---
        self.excel_frame = tk.LabelFrame(self.root, text=" ⚙️ Configuración de Selección Excel (Se agregará a los datos actuales) ", 
                                        bg="#1e293b", fg="#38bdf8", font=("Segoe UI", 10, "bold"), padx=15, pady=10)
        
        tk.Label(self.excel_frame, text="Hoja:", bg="#1e293b", fg="white").pack(side="left", padx=5)
        self.sheet_combo = ttk.Combobox(self.excel_frame, state="readonly", width=15)
        self.sheet_combo.pack(side="left", padx=5)
        self.sheet_combo.bind("<<ComboboxSelected>>", self.on_sheet_selected)

        tk.Label(self.excel_frame, text="Seleccionar por:", bg="#1e293b", fg="white").pack(side="left", padx=5)
        self.axis_combo = ttk.Combobox(self.excel_frame, values=["Columna", "Fila", "Toda la Hoja"], state="readonly", width=12)
        self.axis_combo.pack(side="left", padx=5)
        self.axis_combo.bind("<<ComboboxSelected>>", self.on_axis_selected)

        self.idx_label = tk.Label(self.excel_frame, text="Cuál:", bg="#1e293b", fg="white")
        self.idx_label.pack(side="left", padx=5)
        self.index_combo = ttk.Combobox(self.excel_frame, state="readonly", width=10)
        self.index_combo.pack(side="left", padx=5)

        tk.Button(self.excel_frame, text="✅ Combinar con actuales", command=self.import_excel_selection,
                  bg="#10b981", fg="white", font=("Segoe UI", 9, "bold")).pack(side="right", padx=10)

        # --- RESTO DE LA UI ---
        gen_frame = tk.LabelFrame(self.root, text=" ⚡ Generadores Rápidos ", 
                                bg="#1e293b", fg="#94a3b8", font=("Segoe UI", 10, "bold"), padx=15, pady=10)
        gen_frame.pack(fill="x", padx=25, pady=5)

        for fmt, col in [("TXT", "#ef4444"), ("JSON", "#f59e0b"), ("CSV", "#3b82f6"), ("EXCEL", "#10b981")]:
            cmd = self.generate_excel_auto if fmt == "EXCEL" else lambda f=fmt.lower(): self.generate_simple_auto(f)
            tk.Button(gen_frame, text=f"Crear {fmt}", command=cmd, bg=col, fg="white", relief="flat", width=15).pack(side="left", padx=8)

        speed_frame = tk.Frame(self.root, bg="#0f172a")
        speed_frame.pack(fill="x", padx=25, pady=5)
        tk.Label(speed_frame, text="Velocidad Animación:", bg="#0f172a", fg="#94a3b8").pack(side="left")
        self.speed_slider = ttk.Scale(speed_frame, from_=0.15, to=0.0, orient="horizontal")
        self.speed_slider.set(0.01); self.speed_slider.pack(side="left", fill="x", expand=True, padx=10)

        tk.Button(speed_frame, text="🛑 Detener", command=self.stop_sorting, bg="#f43f5e", fg="white", width=12).pack(side="left", padx=5)
        tk.Button(speed_frame, text="🔄 Desordenar", command=self.shuffle_data, bg="#f59e0b", fg="white", width=12).pack(side="left", padx=5)

        self.canvas = tk.Canvas(self.root, width=self.canvas_width, height=self.canvas_height, 
                                bg="#020617", highlightthickness=1, highlightbackground="#1e293b")
        self.canvas.pack(pady=20)

        self.create_algo_buttons()

        self.status_var = tk.StringVar(value="Listo.")
        tk.Label(self.root, textvariable=self.status_var, bg="#1e293b", fg="#38bdf8", anchor="w", padx=10).pack(side="bottom", fill="x")

    def create_algo_buttons(self):
        int_frame = tk.LabelFrame(self.root, text=" 🧠 Algoritmos Internos (Animados) ", 
                                 bg="#1e293b", fg="#fbbf24", font=("Segoe UI", 10, "bold"), pady=10)
        int_frame.pack(fill="x", padx=25, pady=5)
        internos = [("Burbuja", "bubble"), ("Inserción", "insertion"), ("Selección", "selection"),
                    ("Shell", "shell"), ("Quick", "quick"), ("Heap", "heap"), ("Radix", "radix")]
        for text, method in internos:
            tk.Button(int_frame, text=text, command=lambda m=method: self.run_internal(m),
                      bg="#334155", fg="white", width=12, relief="flat").pack(side="left", padx=5)

        ext_frame = tk.LabelFrame(self.root, text=" 💾 Algoritmos Externos (Animados) ", 
                                 bg="#1e293b", fg="#a855f7", font=("Segoe UI", 10, "bold"), pady=10)
        ext_frame.pack(fill="x", padx=25, pady=5)
        externos = [("Intercalación", "intercalacion"), ("Mezcla Directa", "mezcla_directa"), 
                    ("Mezcla Equilibrada", "mezcla_equilibrada")]
        for text, method in externos:
            tk.Button(ext_frame, text=text, command=lambda m=method: self.run_external(m),
                      bg="#a855f7", fg="white", width=22, relief="flat", font=("Segoe UI", 9, "bold")).pack(side="left", padx=12)

    def on_sheet_selected(self, event):
        self.axis_combo.set("")
        self.index_combo['values'] = []
        self.index_combo.config(state="readonly")

    def on_axis_selected(self, event):
        if not self.current_excel_path: return
        selection = self.axis_combo.get()
        if selection == "Toda la Hoja":
            self.index_combo.set(""); self.index_combo.config(state="disabled")
        else:
            self.index_combo.config(state="readonly")
            try:
                wb = load_workbook(self.current_excel_path, read_only=True)
                ws = wb[self.sheet_combo.get()]
                if selection == "Columna":
                    self.index_combo['values'] = [get_column_letter(i) for i in range(1, ws.max_column + 1)]
                else:
                    self.index_combo['values'] = [str(i) for i in range(1, ws.max_row + 1)]
                self.index_combo.current(0)
            except: pass

    def import_excel_selection(self):
        sheet_name = self.sheet_combo.get()
        axis = self.axis_combo.get()
        idx_val = self.index_combo.get()

        if not sheet_name or not axis:
            messagebox.showwarning("Aviso", "Seleccione Hoja y modo de importación.")
            return

        try:
            wb = load_workbook(self.current_excel_path, data_only=True)
            ws = wb[sheet_name]
            extracted = []

            if axis == "Toda la Hoja":
                for row in ws.iter_rows(values_only=True):
                    extracted.extend([int(c) for c in row if isinstance(c, (int, float))])
            elif axis == "Columna":
                extracted = [int(c.value) for c in ws[idx_val] if isinstance(c.value, (int, float))]
            else: # Fila
                extracted = [int(c.value) for c in ws[int(idx_val)] if isinstance(c.value, (int, float))]

            self.all_data.extend(extracted) # AÑADIR A LOS DATOS ACTUALES
            self.draw_bars(self.all_data)
            self.status_var.set(f"Combinados {len(extracted)} elementos de Excel. Total: {len(self.all_data)}")
            self.excel_frame.pack_forget()
        except Exception as e:
            messagebox.showerror("Error", f"Error al importar: {e}")

    def load_multiple_files(self):
        file_paths = filedialog.askopenfilenames()
        if not file_paths: return
        for path in file_paths:
            ext = os.path.splitext(path)[1].lower()
            if ext == ".xlsx":
                self.current_excel_path = path
                self.excel_frame.pack(fill="x", padx=25, pady=5)
                wb = load_workbook(path, read_only=True)
                self.sheet_combo['values'] = wb.sheetnames
                self.sheet_combo.current(0)
                # No cargamos datos aún, esperamos la configuración de Excel
            else:
                try:
                    if ext == ".json":
                        with open(path, 'r') as f: self.all_data.extend(self.extract_nums(json.load(f)))
                    elif ext == ".csv":
                        with open(path, 'r') as f:
                            for r in csv.reader(f): self.all_data.extend([int(x) for x in r if x.strip().lstrip('-').isdigit()])
                    else:
                        with open(path, 'r') as f:
                            text = f.read().replace(',', ' ').split()
                            self.all_data.extend([int(x) for x in text if x.lstrip('-').isdigit()])
                except Exception as e:
                    print(f"Error cargando {path}: {e}")
        self.draw_bars(self.all_data)

    def stop_sorting(self):
        self.sorting_active = False
        self.status_var.set("Detenido.")

    def shuffle_data(self):
        if not self.all_data: return
        random.shuffle(self.all_data); self.draw_bars(self.all_data)

    def add_manual_data(self):
        raw = self.manual_entry.get().replace(',', ' ')
        try:
            nums = [int(x) for x in raw.split() if x.lstrip('-').isdigit()]
            self.all_data.extend(nums); self.draw_bars(self.all_data)
            self.manual_entry.delete(0, tk.END)
        except: pass

    def clear_data(self):
        self.all_data = []; self.canvas.delete("all")
        self.status_var.set("Limpio."); self.excel_frame.pack_forget()

    def extract_nums(self, obj):
        nums = []
        if isinstance(obj, list):
            for i in obj: nums.extend(self.extract_nums(i))
        elif isinstance(obj, dict):
            for v in obj.values(): nums.extend(self.extract_nums(v))
        elif isinstance(obj, (int, float)): nums.append(int(obj))
        return nums

    def generate_simple_auto(self, fmt):
        nums = [random.randint(1, 1000) for _ in range(50)]
        path = os.path.join(self.output_dir, f"gen_{datetime.now().strftime('%H%M%S')}.{fmt}")
        with open(path, 'w') as f: f.write(" ".join(map(str, nums)))
        messagebox.showinfo("Generador", "Creado.")

    def generate_excel_auto(self):
        wb = Workbook(); ws = wb.active
        for r in range(1, 21): ws.cell(r, 1, random.randint(1, 100))
        path = os.path.join(self.output_dir, f"gen_{datetime.now().strftime('%H%M%S')}.xlsx")
        wb.save(path); messagebox.showinfo("Generador", "Excel creado.")

    def draw_bars(self, arr, color_map=None):
        if not self.sorting_active and color_map is not None: raise StopIteration("Cancelado")
        self.canvas.delete("all")
        if not arr: return
        n, w, mx = len(arr), self.canvas_width / len(arr), max(arr) if arr else 1
        for i, v in enumerate(arr):
            color = color_map.get(i, "#38bdf8") if color_map else "#38bdf8"
            h = (v / mx) * (self.canvas_height - 20)
            self.canvas.create_rectangle(i*w, self.canvas_height-h, (i+1)*w, self.canvas_height, fill=color, outline="#020617")
        self.root.update()

    def run_internal(self, method_name):
        if not self.all_data: return
        self.sorting_active = True; data_copy = list(self.all_data)
        try:
            res = getattr(InternalSort, method_name)(data_copy, callback=self.draw_bars, delay=self.speed_slider.get())
            self.all_data = res; self.draw_bars(self.all_data); self.final_step(self.all_data)
        except StopIteration: pass
        finally: self.sorting_active = False

    def run_external(self, method_name):
        if not self.all_data: return
        self.sorting_active = True; data_copy = list(self.all_data)
        try:
            if method_name == "intercalacion":
                mid = len(data_copy) // 2
                res = ExternalSort.intercalacion(sorted(data_copy[:mid]), sorted(data_copy[mid:]), callback=self.draw_bars, start_idx=0, full_arr=list(data_copy))
            else:
                res = getattr(ExternalSort, method_name)(data_copy, callback=self.draw_bars)
            self.all_data = res; self.draw_bars(self.all_data); self.final_step(self.all_data)
        except StopIteration: pass
        finally: self.sorting_active = False

    def final_step(self, data):
        if not self.sorting_active and messagebox.askyesno("Guardar", "¿Exportar a Excel?"):
            path = filedialog.asksaveasfilename(defaultextension=".xlsx")
            if path:
                wb = Workbook(); ws = wb.active
                for i, v in enumerate(data): ws.cell(i+1, 1, v)
                wb.save(path)

if __name__ == "__main__":
    root = tk.Tk(); app = SortingApp(root); root.mainloop()