import time

class InternalSort:
    @staticmethod
    def bubble(arr, callback=None, delay=0.01):
        n = len(arr)
        for i in range(n):
            for j in range(0, n - i - 1):
                if arr[j] > arr[j + 1]:
                    arr[j], arr[j + 1] = arr[j + 1], arr[j]
                    if callback:
                        callback(arr, {j: "#f43f5e", j+1: "#f43f5e"})
                        time.sleep(delay)
        return arr

    @staticmethod
    def insertion(arr, callback=None, delay=0.01):
        for i in range(1, len(arr)):
            key = arr[i]
            j = i - 1
            while j >= 0 and key < arr[j]:
                arr[j + 1] = arr[j]
                j -= 1
                if callback:
                    callback(arr, {j+1: "#f43f5e", i: "#fbbf24"})
                    time.sleep(delay)
            arr[j + 1] = key
            if callback: callback(arr)
        return arr

    @staticmethod
    def selection(arr, callback=None, delay=0.01):
        for i in range(len(arr)):
            min_idx = i
            for j in range(i + 1, len(arr)):
                if callback:
                    callback(arr, {i: "#fbbf24", j: "#f43f5e", min_idx: "#10b981"})
                    time.sleep(delay)
                if arr[j] < arr[min_idx]:
                    min_idx = j
            arr[i], arr[min_idx] = arr[min_idx], arr[i]
        return arr

    @staticmethod
    def shell(arr, callback=None, delay=0.01):
        n = len(arr)
        gap = n // 2
        while gap > 0:
            for i in range(gap, n):
                temp = arr[i]
                j = i
                while j >= gap and arr[j - gap] > temp:
                    arr[j] = arr[j - gap]
                    j -= gap
                    if callback:
                        callback(arr, {j: "#f43f5e", i: "#fbbf24"})
                        time.sleep(delay)
                arr[j] = temp
            gap //= 2
        return arr

    @classmethod
    def quick(cls, arr, callback=None, delay=0.01, start=0, full_arr=None):
        if full_arr is None: full_arr = list(arr)
        if len(arr) <= 1: return arr
        pivot = arr[len(arr) // 2]
        left = [x for x in arr if x < pivot]
        middle = [x for x in arr if x == pivot]
        right = [x for x in arr if x > pivot]
        res = left + middle + right
        full_arr[start:start+len(res)] = res
        if callback:
            callback(full_arr, {start + len(left): "#10b981"})
            time.sleep(delay)
        return cls.quick(left, callback, delay, start, full_arr) + \
               middle + \
               cls.quick(right, callback, delay, start + len(left) + len(middle), full_arr)

    @staticmethod
    def heap(arr, callback=None, delay=0.01):
        def heapify(n, i):
            largest = i
            l, r = 2 * i + 1, 2 * i + 2
            if l < n and arr[i] < arr[l]: largest = l
            if r < n and arr[largest] < arr[r]: largest = r
            if largest != i:
                arr[i], arr[largest] = arr[largest], arr[i]
                if callback:
                    callback(arr, {i: "#f43f5e", largest: "#fbbf24"})
                    time.sleep(delay)
                heapify(n, largest)
        n = len(arr)
        for i in range(n // 2 - 1, -1, -1): heapify(n, i)
        for i in range(n - 1, 0, -1):
            arr[i], arr[0] = arr[0], arr[i]
            if callback:
                callback(arr, {i: "#10b981", 0: "#f43f5e"})
                time.sleep(delay)
            heapify(i, 0)
        return arr

    @staticmethod
    def radix(arr, callback=None, delay=0.01):
        if not arr: return arr
        max_val = max(arr)
        exp = 1
        while max_val // exp > 0:
            output, count = [0] * len(arr), [0] * 10
            for i in arr: count[(i // exp) % 10] += 1
            for i in range(1, 10): count[i] += count[i - 1]
            for i in range(len(arr) - 1, -1, -1):
                index = (arr[i] // exp) % 10
                output[count[index] - 1] = arr[i]
                count[index] -= 1
                if callback:
                    callback(output, {count[index]: "#10b981"})
                    time.sleep(delay)
            arr, exp = output[:], exp * 10
        return arr