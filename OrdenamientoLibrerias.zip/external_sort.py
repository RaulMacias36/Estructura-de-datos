import time

class ExternalSort:
    @staticmethod
    def intercalacion(arr1, arr2, callback=None, start_idx=0, full_arr=None):
        result = []
        i = j = 0
        while i < len(arr1) and j < len(arr2):
            if arr1[i] < arr2[j]:
                result.append(arr1[i]); i += 1
            else:
                result.append(arr2[j]); j += 1
            if callback and full_arr is not None:
                current_prog = result + arr1[i:] + arr2[j:]
                full_arr[start_idx : start_idx + len(current_prog)] = current_prog
                callback(full_arr, {start_idx + len(result) - 1: "#a855f7"}) 
        result.extend(arr1[i:]); result.extend(arr2[j:])
        if callback and full_arr is not None:
            full_arr[start_idx : start_idx + len(result)] = result
            callback(full_arr)
        return result

    @classmethod
    def mezcla_directa(cls, arr, callback=None, start_idx=0, full_arr=None):
        if full_arr is None: full_arr = list(arr)
        if len(arr) <= 1: return arr
        mid = len(arr) // 2
        izq = cls.mezcla_directa(arr[:mid], callback, start_idx, full_arr)
        der = cls.mezcla_directa(arr[mid:], callback, start_idx + mid, full_arr)
        return cls.intercalacion(izq, der, callback, start_idx, full_arr)

    @classmethod
    def mezcla_equilibrada(cls, arr, callback=None):
        if not arr: return arr
        def obtener_tramos(data):
            tramos, indices = [], [0]
            if not data: return tramos, indices
            actual = [data[0]]
            for i in range(1, len(data)):
                if data[i] >= data[i-1]: actual.append(data[i])
                else:
                    tramos.append(actual); indices.append(i); actual = [data[i]]
            tramos.append(actual); return tramos, indices
        full_arr = list(arr)
        tramos, indices = obtener_tramos(full_arr)
        while len(tramos) > 1:
            nuevos_tramos, nuevos_indices = [], []
            for i in range(0, len(tramos), 2):
                if i + 1 < len(tramos):
                    idx_inicio = indices[i]
                    mezclados = cls.intercalacion(tramos[i], tramos[i+1], callback, idx_inicio, full_arr)
                    nuevos_tramos.append(mezclados); nuevos_indices.append(idx_inicio)
                else:
                    nuevos_tramos.append(tramos[i]); nuevos_indices.append(indices[i])
            tramos, indices = nuevos_tramos, nuevos_indices
        return tramos[0] if tramos else []